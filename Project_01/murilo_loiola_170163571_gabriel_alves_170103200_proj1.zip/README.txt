No ubuntu, sistema operacional utilizado para o desenvolvimento dos códigos, a compilação e execução deve ser feita da seguinte forma:
Problema 01:
gcc problema_01.c
./a.out
Problema 02:
gcc problema_02.c
./a.out
Problema 03:
gcc problema_03.c
./a.out
